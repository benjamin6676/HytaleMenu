# Hytale Security Tester

A packet capture, analysis and security testing tool for Hytale servers.
Built with .NET 10, Silk.NET, ImGui.NET.

---

## Build

```
dotnet restore
dotnet build
dotnet run
```

Requires .NET 10 SDK and Windows x64.

---

## Tabs

| Tab | Status | What it does |
|-----|--------|-------------|
| Dashboard | ✅ | Server config, IP presets, ping, geo lookup, port scan |
| Packet Exploiting | ✅ | Malformed packets, replay, flood, sequence manipulation |
| Dupe Methods | ✅ | Drop race, trade race, container race, rollback, timing sweep |
| Capture | ✅ | UDP proxy + TCP capture, packet list |
| Privilege Escalation | ✅ | Give item, command inject, permission spoof — with auto-fill |
| Item Inspector | ✅ | Scans captured packets for item ID / stack / slot fields |
| Response Analyser | ✅ | Correlates sent packets with server responses |
| Diff Analysis | ✅ | Byte-level diff between two captured packets |
| Packet Book | ✅ | Save, name, replay named packets |
| Connection | ✅ | Handshake and connection analysis |
| Log | ✅ | General log (top) + packet traffic feed (bottom) |
| Memory Reader | ✅ | Process attach, read, pattern scan, value scan, AOB, memory map, pointer path |

---

## How to capture packets

1. Open **Capture** tab
2. Set server IP/port in **Dashboard** (or use a preset)
3. Click **Start UDP Proxy** — configure your game client to connect to `127.0.0.1:PORT`
4. Play normally — packets appear in **Packet Traffic** pane in **Log** tab
5. Use spam suppression to hide keep-alive opcodes

---

## Packet Exploiting

The **Packet Exploiting** status bar shows UDP proxy status correctly. Requires UDP proxy running (Capture tab).

- **Replay**: paste hex from Capture tab → set count/delay → Start Replay
- **Flood**: stress-test rate limiting
- **Sequence test**: out-of-order and duplicate sequence IDs
- **Malformed**: arbitrary payload with padding

---

## Privilege Escalation

Click **⟳ Auto-fill IDs from packets** to populate ItemID and PlayerID from recently captured traffic. Also use the ⟳ button next to individual fields.

Packet IDs (0x2A, 0x01) are best-guess placeholders — use Packet Book + Response Analyser to find the real IDs by capturing and replaying game actions.

---

## Item Inspector

Scans captured UDP/TCP packets for byte patterns that match item IDs (100–9999), adjacent stack counts (1 byte) and slot indices (1 byte). Works best when you:

1. Start UDP proxy
2. Pick up / drop / swap an item in-game
3. Open Item Inspector → click **Scan Now** or wait for auto-scan

The Item Inspector shows candidate item IDs from packet data — cross-reference the ID shown with what you're actually holding.

---

## Response Analyser

Works only when packets are being sent **through** the proxy (UDP or TCP). The tracker correlates outgoing test packets with incoming server responses within a configurable window (default 500ms).

To use:
1. Start UDP proxy in Capture tab
2. Use Manual Test Fire in Response Analyser — or fire from any other tab
3. Results appear in the feed with ACCEPTED / DENIED / NO REPLY classification

---

## Memory Reader

Attaches to a running process using `ReadProcessMemory` (read-only, no injection).

### Sub-tabs

**Attach** — browse running processes, click to attach. Quick attach for Hytale/java.

**Read** — enter any hex address, read N bytes. Shows hex dump + interpreted values (int8–64, float, double, ptr, ASCII string).

**Pattern Scan** — hex byte pattern with `??` wildcards across all readable memory regions.

**Value Scan (rescan workflow)**:
1. Enter range (e.g. 100–9999 for item IDs), click **Initial Scan**
2. Change the value in-game (pick up different item / change stack count)
3. Enter the new value in **New min/New max**, click **Rescan**
4. Repeat until 1–3 addresses remain

**Inventory Scan** — heuristic scan for int32 clusters that look like `[itemId][stackCount][slotIndex]`. Cross-reference with Item Inspector packet data to confirm.

**AOB Scan** — high-performance `ReadOnlySpan<byte>` scan of a specific module (or all modules). Enter pattern with `??` wildcards, select module from dropdown, click Scan.

**Memory Map** — full virtual memory map of the process. Filter by type (IMAGE/MAPPED/PRIVATE), protection, readable-only toggle.

**Pointer Path** — resolve a multi-level pointer chain. Enter base address + space-separated hex offsets. Useful for tracking dynamic game objects whose address changes each session.

---

## Entity Visualizer

`Application.EntityPositions` accepts `EntityOverlayEntry` objects with world-space `Vector3` positions. Set `Application.ViewProjectionMatrix` to the game's current VP matrix (from memory reader). The overlay draws ESP-style bounding boxes with corner ticks on the background draw list behind all UI.

---

## Log Tab

- **General Log** (top) — test results, start/stop events, errors. No packet spam.
- **Packet Traffic** (bottom) — live packet feed with:
  - C→S / S→C / Injected filters
  - **Spam suppression** — opcodes seen ≥ threshold times are auto-hidden. Click the opcode badge to un-hide.
  - **Regex filter** — type a regex to show only matching lines (e.g. `^.*C→S.*` or `48 8B`)

---

## Dashboard Presets

Type an IP, set a port, enter a label, click **Save Preset**. Preset buttons appear next to the IP field — click to load. The built-in preset points to the known Hytale test server IP.

---

## Changelog

### v4 (current)
- **Fix**: Packet Exploiting status bar now correctly shows UDP proxy state
- **Fix**: Response Analyser wired to both UDP and TCP capture feeds
- **Fix**: PrivilegeTab placeholder warnings removed; auto-fill bar added
- **Fix**: Value scan rescan description clarified with step-by-step workflow
- **New**: Dashboard IP presets
- **New**: Log packet traffic spam suppression with per-opcode hide buttons
- **New**: Log regex filter
- **New**: Memory Reader — AOB Scan (ReadOnlySpan, module-targeted, fast)
- **New**: Memory Reader — Memory Map viewer
- **New**: Memory Reader — Pointer Path chain resolver
- **New**: Memory Reader — Module list in AOB tab
- **New**: Entity Visualizer with WorldToScreen projection and ImGui background draw list bounding boxes
- **New**: ContextFiller — auto-extracts ItemID/PlayerID from recent packets

### v3
- Memory Reader tab added
- Separate packet log (PacketLog ring buffer)
- Log tab split into General Log + Packet Traffic panes

### v2
- UI fixes: text size, Item Inspector lag, Rnd button, Dupe window heights
- Dashboard detected connections rewritten for Windows
- Silk.NET 2.22.0, net10.0
